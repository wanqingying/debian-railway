# Scheduled Tasks module

Server-owned scheduled task runtime and routes for OpenChamber-only automation.

## Scope

- Per-project scheduled task persistence is owned by `packages/web/server/lib/projects/project-config.js`.
- Markdown loop discovery/parsing is owned by `packages/web/server/lib/scheduled-tasks/loops.js`.
- Runtime orchestration and execution is owned by `packages/web/server/lib/scheduled-tasks/runtime.js`.
- This module is OpenChamber feature logic; it is intentionally separate from OpenCode proxy/runtime internals.
- The chats scope is owned by `packages/web/server/lib/scheduled-tasks/chats-scope.js`.

## Chats scope

Chats (sessions outside any project) can have scheduled tasks too. They are
scheduled like one more project, with three differences:

- **Identity.** The UI and the routes address the scope as `openchamber:chats`
  (the UI's `CHAT_DRAFT_PROJECT_ID`). A colon is not a valid Windows file name,
  so tasks are stored under the chats root's path id
  (`createProjectIdFromPath(<chats root>)`, the same id agent memory uses for
  chats). The service maps the public id to the storage id on the way in, and
  `openchamber:scheduled-task-ran` events map it back on the way out.
- **One new chat per run.** A project run works in the project path. A chats run
  creates `<chats root>/<yyyy-mm-dd>/session-<uuid>`, the layout the UI uses for
  a new chat, and starts the session there, so each run lands in the sidebar's
  chats section as its own chat. If the session cannot be created, the empty
  directory is removed. The run result carries the directory, so "Run now" can
  open the new chat.
- **No loop files.** The chats root is not a repository. User-scope loops
  already run once per project, so the chats scope never discovers loops.
- **Directory resolution.** `resolveProjectID({ directory })` maps any
  directory inside the chats root to the chats scope, after checking registered
  projects, so an agent working in a chat schedules into chats. Any directory
  inside a registered checkout resolves to that project — a linked Git
  worktree via `resolvePrimaryWorktreeRoot`, and a plain subdirectory because
  git reports the checkout as its primary root — so a worktree or
  subdirectory session schedules for the project it belongs to; anything
  still unmatched fails as not-found.

The chats root is `OPENCHAMBER_CHATS_DIR` (default `<config root>/chats`). The
VS Code extension has no chats, so its UI does not offer the scope.

## Cross-instance occurrence claiming

Multiple OpenChamber server processes can share the same on-disk project config
(for example CLI `serve` on port 3000 and the Electron desktop server on port
57123). Each process keeps its own timers, so without coordination a daily (or
weekly / cron / once) slot would dispatch twice.

Before a **scheduled** run creates a session, the runtime claims the occurrence
in shared project config under the project write lock:

- Writes `state.lastScheduledFor` to the armed `nextRunAt` timestamp and advances
  `state.nextRunAt` to the following occurrence.
- A second instance that loses the claim skips session creation and reschedules
  from the winner's persisted `nextRunAt`.
- Project config writes also take a cross-process `.json.lock` file so the
  read-modify-write is serialized across processes, not only within one process.
- `syncAllProjects` (startup and every full resync) syncs each registered
  project on its own: a project whose config cannot be read or written (a
  broken file, a lock timeout) is logged with its id and skipped, and every
  other project's tasks are still scheduled. Only `listProjects` failing
  aborts the sync as a whole. `syncProject` for one project still throws, so
  a route for that project reports the failure.
- The sharing processes may run different OpenChamber versions. Normalization
  keeps only the fields a build knows, so every writer persists tasks it did
  not change verbatim from disk and swaps only `state` onto a task whose state
  it updated; a task goes out normalized only when it was deliberately
  replaced (upsert, loop adoption). An older server touching the file after a
  run therefore cannot strip fields a newer build added, such as a task's goal
  or auto-accept settings.
- Lock timeout / filesystem errors on claim, manual-start, or completion state
  writes always release the in-process running slot (via `finally`) and best-effort
  re-arm the **next future** occurrence; they must not leave the task permanently
  "running" or reject unhandled from the queue pump.
- Project write locks release the in-process promise chain even when
  `acquireProjectFileLock` times out, so a later write for the same project can
  proceed after the on-disk lock is cleared (a hung chain would permanently wedge
  every mutating API and strand `runTask` before its `finally`).
- Re-arm helpers only schedule a persisted `nextRunAt` when it is still in the
  future. A past slot (common for `once` after claim, which cannot advance
  `nextRunAt`) falls back to `computeNextRunAt` — which returns null for a
  consumed/past once occurrence — so a losing instance stops instead of
  spinning delay-0 timers against the project lock.
- On claim lock/fs failure, best-effort persist `lastStatus: error` + `lastError`
  when nobody else claimed the occurrence, so a past `once` task is not left
  enabled-but-inert with only a warn log. Recurring schedules still re-arm the
  next slot.
- On completion-write failure after a session already ran, in-memory status is
  set to a terminal value and a single persist retry is attempted so
  `lastStatus` does not stay `running`. Manual `runNow` still returns the
  `sessionID` as a successful dispatch (`ok` follows run status, with
  `persistError` set) rather than a hard 500; the run API and Scheduled Tasks
  UI surface `persistError` as a warning toast.
- The claim predicate rejects a duplicate solely via `lastScheduledFor` within
  slack of this occurrence. It does not consult advanced on-disk `nextRunAt`
  (that field is routinely overwritten by a second instance syncing inside
  `TASK_DUE_SLACK_MS`, including on later days when `lastScheduledFor` is already
  set from a prior claim).
- Claiming always writes `nextRunAt` (including `undefined`) so a past once-slot
  is cleared when there is no following occurrence.

Manual `runNow` does not claim a schedule occurrence. It also runs paused
(`enabled: false`) tasks — that is the point of the button — while scheduled
dispatches still skip disabled tasks, and completion never re-arms a paused task.

## Existing-session tasks

`targetSessionId` sends to an existing session instead of creating one.
`existing-session.js` validates changed or enabled targets on save, and all
targets on admission and send. A paused task can keep a stale target. The
target must be active and belong to the task project or its linked worktree.
Another registered project owns its exact checkout. Chats targets must remain
inside the chats scope. Missing targets return 404; archived or foreign targets
return 409, including through Run now.

`resolveExecutionDirectory` on the task service returns the project checkout
or Chats root after scope ID normalization. For a target task it reuses
`existing-session.js` target validation and returns the session's own directory.
The control actions use this directory for named-model catalog checks, so a
target in a linked worktree uses that worktree's configuration.

Target discovery asks the same rule rather than reproducing it:
`POST /api/projects/:projectId/scheduled-tasks/targets/eligible` takes the
candidate sessions the editor already holds (at most 500 per request; the
editor sends larger lists in batches), each with its directory, and returns the
ones whose directory belongs to the task project by `validateTarget`'s rule,
resolving worktree ownership through Git once per directory. Discovery does not
check that a session still exists; that stays with `validateTarget`. The picker filters on that answer, so the renderer's current
worktree topology never decides eligibility, and `validateTarget` stays the
final authority on save, admission and send.

The prompt enters the ordinary server message queue with `scheduledTask`
provenance. One project and task can have at most one waiting prompt. Run now
on an already queued prompt records `skipped` and returns 409 with
`busy: queued`. Admission sets `lastSessionId` to the target. Disable, delete
and retarget cancel waiting prompts, but cannot recall a send already in flight.
Saving an already-paused task with the same target keeps a prompt admitted by
Run now. Cancellation on disable applies only to an enabled-to-disabled change.
Scheduled once tasks are disabled after an admission attempt, including a
failed attempt. An admitted prompt stays queued. Run now can still admit a
paused task.

An overlapping admission attempt records `skipped` before the active admission
records `queued`. A later duplicate enqueue records `skipped` while the earlier
prompt remains waiting. The card shows the last attempt's status in that case.

Reuse status ends at queue send: `queued` becomes `sent`, `failed` or
`cancelled`. The existing task state fields hold the result. There is no
per-run history or assistant-completion tracking. `execution.useDefaults`
leaves the target model and agent unchanged. A pinned selection switches the
requested model and agent before sending. Tasks without a target keep the
new-session execution path below.

Reuse preserves the target's goal and permission auto-accept policy. Task
creation options for these policies are hidden in Existing mode and ignored
by the reuse runtime. Transient queue send failures use the ordinary retry
policy. Only definitive before-send target or task 404 or 409 refusals are
terminal, including removed or retargeted tasks and moved targets. Model or
prompt send errors use the ordinary retry path.

## Slash-command prompts

Slash-command prompts share one parser with the session routes. After trimming
the whole prompt, the first token after `/` names the command. Arguments retain
interior spaces, tabs, blank lines, indentation and CRLF. Only spaces or tabs
after the command token and at most one following line break are removed.

### Why arguments are sliced from the prompt

Slicing preserves instructions and formatting in later paragraphs. Splitting
and rejoining tokens would discard line breaks and collapse argument spacing.

## New-session selection

A task either pins them (`execution.providerID`, `modelID`, `variant`, `agent`)
or sets `execution.useDefaults: true`. Such a task reads the session defaults
when each run starts (`session-defaults.js`: the project's `defaultModel` /
`defaultVariant` / `defaultAgent`, then the global ones), so changing a default
reaches it on its next run without editing it. With nothing set, the session is
created without a model or agent and OpenCode applies its own. A pinned value
stored next to `useDefaults` is kept only for when the task is pinned again.

## Dispatch outcome

A new-session run persists `lastStatus: 'sent'` after dispatch. Task status does
not track the session's later outcome. Worktree cleanup waits for execution
settlement separately.
A failed or timed-out dispatch records `'error'`. The task-run event preserves
`sent` through the shared client translator. Stored `success` values from older
runs remain unchanged.

## Worktree isolation

Project tasks with `runInWorktree: true` create a fresh worktree for each run
through the New worktree dialog's creation pipeline. `baseBranch` selects its
source ref; an absent branch uses the project checkout's `HEAD` at run time.
The editor reuses multi-run's `BranchSelector`, including remote branches, and
hides it while isolation is off. Chats and existing-session dispatches do not
use isolation. Setup commands are outside this implementation.

- Project config stores `runInWorktree: true`, a nonempty `baseBranch`, and
  `cleanupWorktree: false`. Omitted fields preserve stored choices. The source
  branch and cleanup choice survive saving with isolation off and reloading.
  Whitespace or more than 200 characters in a source branch rejects the write;
  the stored ref is never truncated.
- A confirmed non-repository runs in the project directory. An operational Git
  probe error, an unregistered bridge, or failed worktree creation fails the
  run before session creation. The strict Git probe preserves the existing
  unsupported-home/disk-root rule.
- Cleanup defaults on. After the prompt/command is accepted, background cleanup
  uses OpenCode's `experimental.session.wait` to wait for execution settlement
  and checks that no descendant session or Goal Mode goal remains active. It
  also waits for background commands started during this run by the session or
  its descendants. Shells from earlier rounds and unrelated sessions do not
  hold cleanup. Failed metadata, activity, ownership or shell reads keep the
  worktree. The dispatch response
  returns immediately with `sent`. Cleanup removes the worktree without deleting
  its current branch, then explicitly deletes only the branch captured at
  creation. An agent switching to another branch never makes that branch
  eligible for deletion. A failed session creation
  also rolls back both, even with cleanup off. Removal failures are logged
  without replacing the dispatch result. The session record remains readable;
  continuing it in a deleted directory returns 404.
- With cleanup off, the worktree and branch remain available for review. The
  card names the generated branch only for this choice; cleaned-up runs show
  just "own worktree". Kept worktrees accumulate across runs.
- `state.lastRunIsolated` records isolation, and `state.lastRunBranch` records
  the generated branch when cleanup is off. The session-creation callback
  captures these before dispatch so timeout state and the task-run event retain
  them. Successful dispatch still records `sent` as described above.

### Why cleanup follows execution separately

OpenCode accepts a prompt before its agent finishes, so settling the dispatch
request cannot authorize deleting its files. Cleanup has a separate
`maxRunDurationMs` wait budget after dispatch settles. Goal Mode may continue a
session after its first idle, and background commands may still write its files.
These conditions are rechecked every 5 seconds only while cleanup is pending.
A failed check or an expired budget retains the journal and logs the path.
The cleanup signal reaches the idle wait, activity and shell probes, and the
metadata store's SDK request. Cancelling a metadata reader also releases its
wait on shared legacy initialization without cancelling other readers. An
expired budget logs `cleanup-wait-budget-exceeded`; stop cancels quietly and
leaves the record recoverable.

On dispatch watchdog timeout the request may still be in flight; cleanup starts
waiting for execution only once that request settles. If it never settles, the
worktree remains journaled for recovery.

### Why cleanup has a per-run journal

Before sending the prompt, project config stores a `scheduledWorktreeCleanups`
record with the session id, project and worktree directories, directory identity,
created branch, start time and owning process. Runs of the same task keep
separate records. Deleting a task or removing a project from the registry does
not discard its cleanup records.

Startup scans the project config files and resumes these waits without sending
the prompt again. Another live server's records are left to that server. Stop
aborts local waits while preserving the journal. Failed or timed-out cleanup is
retried on the next start.

Successful removal clears the record. If the user already removed or replaced
the worktree directory, a waiting record is discarded without touching the
replacement or deleting a branch. A short project-locked claim marks physical
removal as `removing`; slow Git operations run outside the config lock.
The finalizer checks the cleanup signal after acquiring the lock and after the
last directory identity read, before physical removal. Cancellation retains the
record and releases any claimed owner for recovery; releasing that claim is not
itself cancelled. Journal clearing also checks cancellation under the lock.

A crash between directory and branch deletion resumes that phase and deletes only the
captured branch, tolerating a branch already gone. It never removes a replacement
directory at the old path.

### Why owners include a process instance

`ownerPID` is paired with `ownerInstance`, a native creation fingerprint from
`process-instance.js`. Linux uses the boot UUID and `/proc/<pid>/stat` start
ticks; macOS uses the boot-session UUID and the process creation time from `ps`
in UTC; Windows uses the process's UTC creation ticks through hidden PowerShell.
Native commands have a 2-second deadline. No heartbeat or periodic owner writes
are needed.

A matching live instance is skipped with an info log. A dead process or a
different creation fingerprint resumes recovery even when the PID exists.
Unreadable identities retain the record and log a warning. Records without
`ownerInstance` remain recoverable; their PID alone cannot establish ownership.
Startup reads each distinct owner PID once. Only this process's immutable
identity and boot identity are retained beyond that scan; other PIDs are read
fresh before a removal claim.

## Files

- `packages/web/server/lib/scheduled-tasks/runtime.js`
  - Next-run computation (daily/weekly/cron compatibility)
  - Timer scheduling and queueing
  - Concurrency controls
  - Session create + prompt_async execution
  - Emits OpenChamber task-run events

- `packages/web/server/lib/scheduled-tasks/loops.js`
  - Discovery of `.agents/loops/*.md` (project scope, ancestors up to the worktree root) and `~/.agents/loops/*.md` (user scope)
  - Frontmatter parsing into scheduled-task definitions
  - `syncProject` reconciles discovered loops with the persisted task list on every project sync (startup, task list load, task save/delete)

- `packages/web/server/lib/scheduled-tasks/routes.js`
  - Scheduled task CRUD endpoints
  - Listing tasks reconciles loop files first, so opening the Scheduled Tasks UI discovers file additions, edits, and removals without a server restart
  - Loop-file endpoints toggle `enabled` in frontmatter or delete the authoritative markdown file, then reconcile the project
  - Manual run endpoint
  - OpenChamber events SSE stream endpoint

## Loop file format

Portable, git-commit-able scheduled-task definitions:

```markdown
---
name: daily-digest
schedule: "0 9 * * *"
enabled: true
model: anthropic/claude-sonnet-4-5
agent: plan
timezone: Europe/Kyiv
---
Summarize repository changes since yesterday.
```

Field mapping (model: `packages/ui/src/lib/scheduledTasksApi.ts`):

| Frontmatter | Task field |
|---|---|
| `name` | `name` (required, max 80 characters — longer names are rejected as malformed) |
| `schedule` | `schedule.kind: "cron"` + `schedule.cron` (required, cron-only in the portable format) |
| `enabled` | `enabled` (default `false` — a loop only runs when the file explicitly enables it; add `enabled: true` to activate). For a project-scope loop the file's word is not enough: it runs only once the user enabled it on this machine, see *Local approval* |
| `model` | split on the first `/` into `execution.providerID` / `execution.modelID` (required) |
| `agent` | `execution.agent` (optional) |
| `timezone` | `schedule.timezone` (optional, IANA; defaults to the server zone) |
| body | `execution.prompt` (required) |

`thinking_level` and `goalEnabled`/`goalTokenBudget` are not part of the portable
format (UI/JSON-only today); `daily`/`weekly`/`once` schedules remain UI/JSON-only.
Runtime state (`lastRunAt`, `nextRunAt`, `lastStatus`, `lastError`, `lastSessionId`,
`lastDurationMs`, `lastRunIsolated`, `lastRunBranch`) is never written to the markdown file —
it continues to live in the project config state store.

## Loop reconciliation rules

`projectConfigRuntime.reconcileLoopTasks(projectID, loops)` runs inside the
project write lock on every `syncProject` when the project path is known:

- **Identity.** For loop-owned tasks (carrying the `loopFile` marker) identity
  is the loop file path: a loop takes its task over regardless of the task's
  current name, so renaming the loop (the `name` field, or a UI rename) renames
  the task in place instead of leaving a stale duplicate behind. A loop whose
  name matches a JSON task (no `loopFile`) takes that task over instead: its
  schedule/execution/enabled are overwritten from the file while the task's
  `id` and runtime `state` are preserved (markdown wins on conflict).
- **UI-only fields survive adoption.** Execution fields the file format does
  not define (`goalEnabled`, `goalTokenBudget`, `permissionAutoAccept`,
  `variant`) are preserved from the task when a loop adopts it; only fields the
  file defines are re-applied.
- **Deletion.** A task carrying the `loopFile` marker whose loop file is no
  longer discovered (removed or renamed) is unscheduled (removed from the
  config). The marker is persisted in the config file, so removal is detected
  across restarts. JSON-configured tasks without the marker are never removed.
  A task whose loop file still exists but is currently unparseable is KEPT with
  its last good definition — a transiently malformed file (mid-edit, bad merge)
  never deletes a task or its runtime state.
- **Creation.** Loops without a matching task are created under a deterministic
  `loop:<scope>:<name>` id so runtime state survives restarts. At most one task
  is driven per loop file; orphan duplicates of the same file are unscheduled.
- **Scope precedence.** Project-scope loops shadow user-scope loops with the
  same name; among project files the nearest ancestor wins.
- **Malformed files** (missing `name`/`schedule`/`model`/body, invalid cron,
  unreadable) are reported to the scheduler as `definition: null` entries and
  warned about; they never block valid loops in the same or other scopes.
- **Local approval.** A project-scope loop arrives with the repository, so
  `enabled: true` in its file is the author's suggestion. `reconcileLoopTasks`
  keeps it disabled unless the per-machine project config holds an approval
  (`loopApprovals`: file path -> `loopFingerprint`) matching the file's current
  name, schedule and execution. Enabling a loop in the UI (the loop-file
  endpoint) records that approval; disabling withdraws it. A pull that changes
  what a loop runs or when changes its fingerprint, and the loop waits for a
  new approval. User-scope loops (`~/.agents/loops`) need none. A task the
  gate holds back is returned with `loopApproval`: `required` (never enabled
  here) or `outdated` (enabled, then the file changed); the UI explains the
  pause from it. The field is never stored.
- **Agent tool and CLI.** `setEnabled` (behind `schedule.toggle` and
  `openchamber schedule enable|disable`) changes a loop task the way the
  Scheduled tasks checkbox does, through the loop file. It refuses (409) to
  enable a paused project-scope loop: the approval is the user's decision in
  Scheduled tasks, never an agent's or a script's. Disabling works for every
  loop.
- **Loop-file mutations.** The loop file remains authoritative. The scheduled-
  tasks UI opens it in the built-in file editor, updates its `enabled`
  frontmatter through the loop-file endpoint, and deletes the file through the
  loop-file endpoint after confirmation. Each mutation reconciles the project.
  The general task deletion API still rejects loop-sourced tasks while their
  file exists; once the file is gone, deleting an orphan task is allowed.

## Public exports (runtime.js)

- `createScheduledTasksRuntime(dependencies)`
- Returned API:
  - `start()`
  - `stop()`
  - `syncAllProjects()`
  - `syncProject(projectId)`
  - `runNow(projectId, taskId)`

## Public exports (routes.js)

- `registerScheduledTaskRoutes(app, dependencies)`
- Registers:
  - `GET /api/projects/:projectId/scheduled-tasks`
  - `PUT /api/projects/:projectId/scheduled-tasks`
  - `POST /api/projects/:projectId/scheduled-tasks/targets/eligible`
  - `DELETE /api/projects/:projectId/scheduled-tasks/:taskId`
  - `PATCH /api/projects/:projectId/scheduled-tasks/:taskId/loop-file`
  - `DELETE /api/projects/:projectId/scheduled-tasks/:taskId/loop-file`
  - `POST /api/projects/:projectId/scheduled-tasks/:taskId/run`
  - `GET /api/openchamber/scheduled-tasks/status`
  - `GET /api/openchamber/events`

The shared `/api/openchamber/events` stream also carries web notifications.
Its connection ownership and browser capability flag stay unchanged. Delivery
and duplicate handling are documented in `../notifications/DOCUMENTATION.md`.
