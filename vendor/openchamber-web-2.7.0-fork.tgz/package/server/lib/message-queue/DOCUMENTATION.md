# Message Queue

## Purpose

Owns the messages a user queued while a session was busy, and sends them the
moment the session goes idle. The queue lives in the web server so a closed
tab, a locked phone, or a dropped connection no longer strands it. Structural
template: `permission-auto-accept` — the server is authoritative, the shared UI
renders a projection, and VS Code (which has no server of its own) keeps its
UI-side queue and foreground auto-send hook.

## Files

- `runtime.js` — `createMessageQueueRuntime(...)` (state, persistence,
  dispatch loop, event handling) and `registerMessageQueueRoutes(app, runtime)`.
- `runtime.test.js` — delivery, idleness gates, retries, held delivery, persistence,
  concurrency with in-flight sends, slash commands, and project knowledge.

Wiring: created in `server/index.js` after the global event hub and the
session-knowledge runtime; routes registered in
`opencode/feature-routes-runtime.js` (before the generic OpenCode proxy) with
JSON bodies enabled in `opencode/core-routes.js`; stopped by
`opencode/shutdown-runtime.js`.

## Auto routing

`resolveAutoSelection` (the routing runtime) runs right before the send when
the queued send config names `openchamber/auto`, and answers with the real
model and agent. OpenCode 2.x holds both on the session, so the queue applies
them with the `POST /api/session/:id/model` and `/agent` calls it already
makes. The queue captures the sentinel like any other send config. The request
text it routes on carries the same image attachment fact as a direct send
(`attachmentHint`).

## Item

An item is what the UI would have sent itself, captured at queue time so the
send never re-resolves mutable UI state:

```
{
  id, createdAt,
  content,        // raw text for display and editing
  contextPreview?, // bounded display-only summary captured by the UI
  text,           // text to deliver (agent mention stripped, file mentions resolved); defaults to content
  agentMention?,  // delivered as an `agent` part
  attachments: [{ id, filename, mimeType, size, source, serverPath?, agentPath?, dataUrl }],
  context: [      // what the composer had attached, in send order
    { kind: 'context', text, metadata, instructions? },  // a draft chip or linked issue/PR; metadata is the UI's structured payload
    { kind: 'instruction', text },                       // derived from the text (skill instruction)
    { kind: 'synthetic', text },                         // handed to the composer by another surface
  ],
  sendConfig: { providerID, modelID, agent?, variant? },  // required
  goal?: { objective?, tokenBudget },  // queued with "run as goal" armed
  syntheticIds?   // minted by the first delivery attempt, one per record admitted ahead of the message
}
```

`goal` is the composer's armed goal, taken off the composer when the message
is queued so it belongs to this message and no other. `objective` is present
only when the arming flow supplied its own (the plan flow); otherwise the
delivered `text` is the objective. A goal needs message text. Snapshots keep
`goal`, so the queue row can show it.

The server is a courier for `context`: it validates the shape (a kind it
knows, a `metadata` object on `context` entries) and delivers each entry as a
synthetic text part, an entry's `instructions` going out as its own part just
before it and its `metadata` riding the part verbatim so the timeline renders
the context block back. The payload inside `metadata` is the UI's contract
(`lib/messages/contextParts.ts`), parsed by the UI on the way back.

An attachment's `agentPath` — the file's on-disk location the desktop client
resolved at intake — travels to OpenCode as the prompt file's `name`, the
field the model reads as the file identity, falling back to `filename` when
absent. `filename` itself still rides the attachment unchanged for the UI's
own display.

`parseQueuedItemInput` rejects anything the server could not deliver later
(no text, attachments, or context; missing model; malformed attachment or
context entry). Public snapshots and broadcasts strip the payloads —
attachment `dataUrl` (megabytes of base64) and `context` (a PR diff, say) —
so they do not ride every update; the only way to get them back is a `take`.
`syntheticIds` comes only from the queue file: `parseQueuedItemInput` drops it
from client input, and snapshots leave it out.

Snapshots retain `contextPreview`, capped at 100 characters plus an ellipsis.
It carries the attached comment or context label when `content` is empty and
never replaces editable text or delivered parts. Older items without a summary
derive one from the attached comment metadata or the first non-instruction
context text. This optional field needs no queue-file migration.

## Scheduled items

Scheduled tasks use the same items with an optional `scheduledTask` field
containing `projectId` and `taskId`. Reuse does not change the target's goal or
auto-accept policy.
Only the server can enqueue this provenance. Enqueue deduplicates the project
and task across all session queues. A scheduled item can omit its model to
keep the target session selection. Normal composer items still require their
captured model. The UI retains both kinds in the same projection.

Scheduled send guards and terminal result callbacks apply only to scheduled
items. A definitive before-send target or task refusal with 404 or 409 removes
that item and lets the next item proceed. This includes removed or retargeted
tasks and moved targets. Other validation errors and all send failures use the
existing queue retry policy, including model-switch 404 or 409 responses.
Successful send reports `sent` without waiting for an assistant reply. Removing,
clearing or evicting a waiting scheduled item reports `cancelled`. Scheduled
items can be reordered and removed, but cannot be taken for editing or manual
send. Bulk take returns only ordinary items and leaves scheduled items queued.
Disable, delete and retarget use `cancelScheduledTask`. Existing composer
persistence, retries, directory query and delivery gates remain unchanged.

## Queue file

`<data-dir>/message-queue.json` (`OPENCHAMBER_DATA_DIR` or
`~/.config/openchamber`): `{ version, revision, sessions: { [sessionId]:
{ directory, items } } }`, written atomically (temp file + rename) through a
serialized write chain. A missing file is an empty queue. A malformed file is
a failure, not an empty queue: it is moved aside as
`message-queue.json.corrupt-<timestamp>` before the runtime starts empty, so
the next write cannot overwrite the user's data. A failed read leaves writes
disabled until a later load succeeds. `revision` is a global monotonic counter
bumped on every mutation; clients use it to reject stale snapshots.

In-memory only, deliberately: the in-flight item (`sendingId`), retry
backoff, and abort timestamps. A restart has no in-flight sends; a
persisted "sending" flag would strand a message forever.

## Delivery loop

1. `start()` subscribes to the global upstream hub and loads the file; on
   load and on every hub `connect` it arms every session that has items.
2. `session.status` for a queued session: `idle` arms a short quiet timer
   (500 ms, coalescing the burst around a turn boundary), `busy`/`retry`
   clears it. A `message.updated` for a completed assistant reply arms as
   well, so a missed idle event cannot strand the queue. `session.deleted`
   drops the session's queue. An assistant `MessageAbortedError` records an
   abort.
3. `tick(sessionId)` bails when the queue is empty, an item is in flight, or
   the session is held. It re-arms after a 2 s post-abort hold (the UI's
   old behavior: a stop is not immediately followed by the next prompt) or
   while the head item is in retry backoff.
4. Idleness is re-verified against OpenCode before sending, because
   a prompt into a running turn steers into it instead of starting the
   next one: `GET /api/session/active` must not list the session, and the
   trailing message must not be an unfinished assistant reply (that route
   lists only running sessions, so a missed busy event leaves no entry while
   a turn still streams). An unfinished reply created before this
   runtime started does not block: its run died with the previous server and
   will never complete, so a restored queue would wait on it forever. A reply
   with no `created` time still blocks. A failed fetch is unknown, never idle:
   the tick re-arms with backoff.
   The turn must also be over for the session's subagents: a parent idles
   while a background subagent works and runs again when OpenCode hands the
   result back. While `../opencode/session-activity.js` finds a running descendant
   the head waits (the rerun's idle event re-arms it, a 5 s recheck covers a
   missed one); a failed check is unknown and backs off like the rest.
   The descendant check follows live active sessions through at most 8 parent
   links, including idle intermediate subagents; a deeper chain counts as
   unrelated, as in the UI. Unreadable lineage, cycles and the shared fetch
   deadline keep the queue held with the existing retry policy. It does not scan historical child pages.
5. The head is marked in flight (broadcast), then sent. The captured model and
   agent are switched onto the session first (`POST /session/:id/model`,
   `/agent`), because v2 holds both on the session rather than in the body; a
   captured `openchamber/auto` is resolved into a real pair by the routing
   runtime beforehand. The session's project knowledge is written into its
   instruction entries (`sessionKnowledgeRuntime.sync`, which never fails the
   send). Then the captured context goes ahead as synthetic messages
   (`POST /session/:id/synthetic` with `resume: false`, an attached item's
   metadata riding along). An item with a `goal` starts it the way a
   scheduled goal does: `createSessionGoal` (`../session-goal/create.js`)
   saves the goal through the injected `persistSessionGoal` before anything is
   admitted, so a failed save leaves nothing for the retry to duplicate, and
   the goal briefing goes as the last synthetic message. Before the goal save
   and the first synthetic message, the item's `syntheticIds` are minted and
   saved, and a revert staged on the session (`revert` on its record) is
   committed (`POST /session/:id/revert/commit`): OpenCode's commit deletes
   everything admitted past the revert's boundary, so committing at the prompt
   would delete the context admitted just before it. An item with nothing to
   admit ahead of its message mints no ids and reads no record; a failed save
   or an unreadable record fails the send. Then the message itself:
   - text starting with `/` that names a command in OpenCode's `/command`
     list (skills included) goes to `POST /session/:id/command` (body fields
     `name` and `text` since OpenCode 2.0.8) with its file attachments. The
     command route takes files only, which is why the context went ahead of
     it; sending "/name args" as a prompt instead would skip the template
     OpenCode expands only on that route. The command lookup runs before
     anything is admitted, so a failed lookup fails the send with nothing in
     the session;
   - otherwise `POST /session/:id/prompt` with the user's text, files and
     agent mention.
   Success removes the item, persists, broadcasts, and calls `onPromptSent`.
   Failure keeps the item, backs off
   2 s → 60 s (doubling per consecutive failure of that item), and re-arms.
   A retry, also after a restart, reuses the `syntheticIds`: OpenCode answers a
   second admission of an id with the first one, so a failure between the
   context and the message leaves each synthetic record in the session once.
   The ids end at the mint time, one millisecond apart, so they sort in
   admission order and ahead of the message, whose id OpenCode assigns.
6. The next item goes out after the next busy → idle cycle.

A 2xx HTML app-shell response is a failed dispatch, not acceptance. The queued item stays persisted and uses the existing retry backoff.

## Held delivery

An auto-review run (`../auto-review`) bounces the reviewed session through
idle between its steps, and a queued follow-up must not land in the middle.
The runtime takes `isDeliveryHeld(sessionId)`, the auto-review runtime's
`holdsDelivery`, and the tick delivers nothing while it is true. The run calls
`release(sessionId)` when it ends, which arms a dispatch. `deliveryHoldReady`
(the auto-review's `startupLoad`) gates the first `reconcileAll` after start:
until the auto-review has loaded its runs every session is held, and a tick
that bailed then has nothing to re-arm it.

## Routes (`/api/message-queue`)

Normal authenticated OpenChamber runtime routes; never on browser URL-token
allowlists.

| Route | Purpose |
|---|---|
| `GET /api/message-queue` | Full snapshot `{ revision, sessions[] }` |
| `POST .../sessions/:id/items` | Append `{ directory, item }`; returns `{ revision, session, itemId }` and arms a dispatch (the session may already be idle) |
| `DELETE .../sessions/:id/items/:itemId` | Remove; `409` while that item is in flight |
| `POST .../sessions/:id/items/:itemId/take` | Remove and return the full item (payloads included); `404`/`409` |
| `POST .../sessions/:id/take` | Remove and return every item not in flight, in order |
| `PUT .../sessions/:id/order` | `{ itemIds }` must be a complete permutation |
| `DELETE .../sessions/:id` | Clear; the in-flight item stays |

Every mutation broadcasts `openchamber:message-queue.updated` with
`{ revision, session }` to all connected clients (SSE and WS), so several
devices on one server see one queue. SSE uses the shared control stream at
`/api/openchamber/events`; `/api/global/event` carries no OpenChamber events.
The UI subscribes independently of its OpenCode transport and re-reads the
snapshot whenever either stream reconnects. The session in that payload always names
its `directory`, including the broadcast that removes the last item: the UI
keys its projection by directory, and a broadcast without one left the
delivered message on screen (a session's directory is remembered until the
session is deleted or evicted).

Limits: 20 items per session, 50 sessions (oldest evicted, never one with an
item in flight), 200k characters of content; attachment payloads are bounded
by the route family's 50 MB JSON limit.

## UI ownership

`packages/ui/src/stores/messageQueueStore.ts` is the projection: see its
section in `packages/ui/src/stores/DOCUMENTATION.md`. A session in an isolated
space is queued in this module inside that space, not on the host: the host's
runtime sees the host's events only and never delivers into a space. The host
forwards the space's `openchamber:message-queue.updated` changes to the
browsers, see "Sessions and events" in
`packages/web/server/lib/spaces/DOCUMENTATION.md`. VS Code intentionally
does not use this module; with all OpenChamber webviews closed, queued
messages there are not delivered.
